package com.example.calculator;

import android.os.Bundle;
import android.os.Handler;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private TextView tvResult, tvDateTime;
    private String currentInput = "";
    private String operator = "";
    private double firstNumber = 0;

    private Handler clockHandler = new Handler();
    private Runnable clockRunnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);  // XML layout file name

        tvResult = findViewById(R.id.tvResult);
        tvDateTime = findViewById(R.id.tvDateTime);
        RatingBar ratingBar = findViewById(R.id.ratingBar);

        // Number buttons 0-9
        int[] numberIds = {
                R.id.btn0, R.id.btn1, R.id.btn2, R.id.btn3,
                R.id.btn4, R.id.btn5, R.id.btn6, R.id.btn7,
                R.id.btn8, R.id.btn9
        };

        for (int id : numberIds) {
            findViewById(id).setOnClickListener(view -> {
                Button b = (Button) view;
                currentInput += b.getText().toString();
                tvResult.setText(currentInput);
            });
        }

        // Operator buttons
        findViewById(R.id.btnPlus).setOnClickListener(v -> operatorClicked("+"));
        findViewById(R.id.btnMinus).setOnClickListener(v -> operatorClicked("-"));
        findViewById(R.id.btnMultiply).setOnClickListener(v -> operatorClicked("*"));
        findViewById(R.id.btnDivide).setOnClickListener(v -> operatorClicked("/"));
        findViewById(R.id.btnMod).setOnClickListener(v -> operatorClicked("mod"));
        findViewById(R.id.btnPercent).setOnClickListener(v -> operatorClicked("%"));

        // Clear button (AC)
        findViewById(R.id.btnAC).setOnClickListener(v -> {
            currentInput = "";
            operator = "";
            firstNumber = 0;
            tvResult.setText("0");
        });

        // Equals button (=)
        findViewById(R.id.btnEqual).setOnClickListener(v -> calculateResult());

        // Dot button (.)
        findViewById(R.id.btnDot).setOnClickListener(v -> {
            if (!currentInput.contains(".")) {
                if (currentInput.isEmpty()) {
                    currentInput = "0.";
                } else {
                    currentInput += ".";
                }
                tvResult.setText(currentInput);
            }
        });

        // Square button (x²)
        findViewById(R.id.btnSquare).setOnClickListener(v -> {
            try {
                double value = Double.parseDouble(currentInput);
                double square = value * value;
                currentInput = formatNumber(square);
                tvResult.setText(currentInput);
                operator = "";
            } catch (Exception e) {
                tvResult.setText("Error");
                currentInput = "";
            }
        });

        // Square root button (√)
        findViewById(R.id.btnSqrt).setOnClickListener(v -> {
            try {
                double value = Double.parseDouble(currentInput);
                if (value < 0) {
                    tvResult.setText("NaN");
                    currentInput = "";
                } else {
                    double sqrt = Math.sqrt(value);
                    currentInput = formatNumber(sqrt);
                    tvResult.setText(currentInput);
                    operator = "";
                }
            } catch (Exception e) {
                tvResult.setText("Error");
                currentInput = "";
            }
        });

        // Double button (x2)
        findViewById(R.id.btnDouble).setOnClickListener(v -> {
            try {
                double value = Double.parseDouble(currentInput);
                double doubled = value * 2;
                currentInput = formatNumber(doubled);
                tvResult.setText(currentInput);
                operator = "";
            } catch (Exception e) {
                tvResult.setText("Error");
                currentInput = "";
            }
        });

        // Rating bar listener
        ratingBar.setOnRatingBarChangeListener((ratingBar1, rating, fromUser) -> {
            Toast.makeText(MainActivity.this, "You rated: " + (int) rating + " stars", Toast.LENGTH_SHORT).show();
        });

        // Start clock updates
        startClock();
    }

    private void operatorClicked(String op) {
        try {
            if (!currentInput.isEmpty()) {
                firstNumber = Double.parseDouble(currentInput);
                currentInput = "";
                operator = op;
                tvResult.setText(op);
            }
        } catch (Exception e) {
            tvResult.setText("Error");
            currentInput = "";
        }
    }

    private void calculateResult() {
        try {
            if (operator.isEmpty() || currentInput.isEmpty()) {
                return; // Nothing to calculate
            }
            double secondNumber = Double.parseDouble(currentInput);
            double result;

            switch (operator) {
                case "+":
                    result = firstNumber + secondNumber;
                    break;
                case "-":
                    result = firstNumber - secondNumber;
                    break;
                case "*":
                    result = firstNumber * secondNumber;
                    break;
                case "/":
                    if (secondNumber == 0) {
                        tvResult.setText("Cannot divide by zero");
                        currentInput = "";
                        operator = "";
                        return;
                    } else {
                        result = firstNumber / secondNumber;
                    }
                    break;
                case "%":
                    result = firstNumber * secondNumber / 100;
                    break;
                case "mod":
                    result = firstNumber % secondNumber;
                    break;
                default:
                    return;
            }
            currentInput = formatNumber(result);
            tvResult.setText(currentInput);
            operator = "";

        } catch (Exception e) {
            tvResult.setText("Error");
            currentInput = "";
            operator = "";
        }
    }

    private void startClock() {
        clockRunnable = new Runnable() {
            @Override
            public void run() {
                String time = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
                tvDateTime.setText(time);
                clockHandler.postDelayed(this, 1000);
            }
        };
        clockHandler.post(clockRunnable);
    }

    private String formatNumber(double number) {
        if (number == (long) number) {
            return String.format(Locale.getDefault(), "%d", (long) number);
        } else {
            return String.format(Locale.getDefault(), "%.6f", number).replaceAll("0+$", "").replaceAll("\\.$", "");
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        clockHandler.removeCallbacks(clockRunnable);
    }
}
